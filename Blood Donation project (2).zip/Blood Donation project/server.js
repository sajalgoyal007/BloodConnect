
// const express = require('express');
// const fs = require('fs');
// const path = require('path');

// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };

// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate age range
//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     const duplicate = donors.some(d => d.name === name && d.contact === contact);
//     if (duplicate) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save new donor
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood
// app.post('/submit_request', (req, res) => {
//     console.log("🔍 Form Received: ", req.body);
//     const { name, bloodGroup, contact, hospital, message, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         console.error("❌ Invalid blood group:", req.body);
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, message, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);

//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Match donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase());

//     // Generate response page
//     let responseHtml = `
//     <style>
//         body {
//             font-family: Arial, sans-serif;
//             background: linear-gradient(to bottom right, #FF4E50, #FC913A);
//             color: white;
//             text-align: center;
//             padding-top: 50px;
//             animation: fadeIn 1.5s ease-in-out;
//         }
//         h1 {
//             font-size: 3em;
//             text-shadow: 2px 2px 5px black;
//         }
//         h2 {
//             color: #FFD700;
//             text-decoration: underline;
//         }
//         ul {
//             list-style: none;
//             padding: 0;
//         }
//         li {
//             margin: 10px 0;
//             padding: 15px;
//             background: rgba(0, 0, 0, 0.3);
//             border-radius: 10px;
//             box-shadow: 0 0 10px #FFD700;
//             animation: slideIn 0.8s ease-in-out;
//         }
//         a {
//             display: inline-block;
//             margin-top: 30px;
//             padding: 15px 30px;
//             background: #00E676;
//             color: white;
//             text-decoration: none;
//             font-weight: bold;
//             border-radius: 30px;
//             box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
//         }
//     </style>
//     <h1>Blood Request Submitted Successfully! 💉</h1>`;

//     // Display matched donors
//     if (matchedDonors.length > 0) {
//         responseHtml += '<h2>Matched Donors:</h2><ul>';
//         matchedDonors.forEach(donor => {
//             responseHtml += `<li>${donor.name} (Age: ${donor.age}) - 📞 ${donor.contact} (${donor.city})</li>`;
//         });
//         responseHtml += '</ul>';
//     } else {
//         responseHtml += '<p>No matching donors found. 😞</p>';
//     }

//     responseHtml += '<a href="/">🔙 Go Back</a>';
//     res.send(responseHtml);
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });




// const express = require('express');
// const fs = require('fs');
// const path = require('path');

// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };

// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate age range
//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Validate contact number (10 digits)
//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     const duplicate = donors.some(d => d.contact === contact);
//     if (duplicate) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save new donor
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood
// app.post('/submit_request', (req, res) => {
//     console.log("🔍 Form Received: ", req.body);
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);

//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Match donors based on blood group and location
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors
//         .filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         })
//         .sort((a, b) => a.distance - b.distance);

//     // Generate response page
//     let responseHtml = `
//     <h1>Blood Request Submitted Successfully! 💉</h1>
//     <h2>Matched Donors (Sorted by Distance):</h2>
//     <ul>`;

//     if (matchedDonors.length > 0) {
//         matchedDonors.forEach(donor => {
//             responseHtml += `<li>${donor.name} (Age: ${donor.age}) - 📞 ${donor.contact} (${donor.city}) - 📍 ${donor.distance} km away</li>`;
//         });
//     } else {
//         responseHtml += '<p>No matching donors found. 😞</p>';
//     }

//     responseHtml += '</ul><a href="/">🔙 Go Back</a>';
//     res.send(responseHtml);
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });


// const express = require('express');
// const fs = require('fs');
// const path = require('path');

// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate age range
//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Validate contact number (10 digits)
//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     const duplicate = donors.some(d => d.contact === contact);
//     if (duplicate) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save new donor with location
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood
// app.post('/submit_request', (req, res) => {



//     app.post('/submit_request', (req, res) => {



//         // Request Blood
// app.post('/submit_request', (req, res) => {
//     console.log("🔍 Form Received: ", req.body);
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate required fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save the blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);

//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Load donor data and match by blood group
//     const donors = loadData(donorsFilePath);
//     let matchedDonors = [];

//     // If donors exist, calculate distance and filter by blood group
//     if (donors.length > 0) {
//         matchedDonors = donors
//             .filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//             .map(donor => {
//                 const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//                 return { ...donor, distance: distance.toFixed(2) };
//             })
//             .sort((a, b) => a.distance - b.distance);
//     }

//     // Redirect to response page with matched donors (or empty array if none found)
//     res.redirect(`/response.html?donors=${encodeURIComponent(JSON.stringify(matchedDonors))}`);
// });


//     // Generate response page
//     let responseHtml = `
//     <h1>✅ Blood Request Submitted Successfully!</h1>
//     <h2>🔎 Matched Donors (Sorted by Distance):</h2>
//     <ul>`;

//     if (matchedDonors.length > 0) {
//         matchedDonors.forEach(donor => {
//             responseHtml += `<li>${donor.name} (Age: ${donor.age}) - 📞 ${donor.contact} (${donor.city}) - 📍 ${donor.distance} km away</li>`;
//         });
//     } else {
//         responseHtml += '<p>❌ No matching donors found. 😞</p>';
//     }

//     responseHtml += '</ul><a href="/">🔙 Go Back</a>';
//     res.send(responseHtml);
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });


// const express = require('express');
// const fs = require('fs');
// const path = require('path');

// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate all required fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate age range
//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Validate contact number (10 digits)
//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     const duplicate = donors.some(d => d.contact === contact);
//     if (duplicate) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save new donor with location
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood
// app.post('/submit_request', (req, res) => {
//     console.log("🔍 Form Received: ", req.body);
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate required fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     // Validate blood group
//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save the blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);

//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Load donor data and match by blood group
//     const donors = loadData(donorsFilePath);
//     let matchedDonors = [];

//     // If donors exist, calculate distance and filter by blood group
//     if (donors.length > 0) {
//         matchedDonors = donors
//             .filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//             .map(donor => {
//                 const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//                 return { ...donor, distance: distance.toFixed(2) };
//             })
//             .sort((a, b) => a.distance - b.distance);
//     }

//     // Generate response page
//     let responseHtml = `
//     <h1>✅ Blood Request Submitted Successfully!</h1>
//     <h2>🔎 Matched Donors (Sorted by Distance):</h2>
//     <ul>`;

//     if (matchedDonors.length > 0) {
//         matchedDonors.forEach(donor => {
//             responseHtml += `<li>${donor.name} (Age: ${donor.age}) - 📞 ${donor.contact} (${donor.city}) - 📍 ${donor.distance} km away</li>`;
//         });
//     } else {
//         responseHtml += '<p>❌ No matching donors found. 😞</p>';
//     }

//     responseHtml += '</ul><a href="/">🔙 Go Back</a>';
//     res.send(responseHtml);
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });



// Import required modules
// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const twilio = require('twilio');
// require('dotenv').config();

// // Initialize the app
// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure required directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Twilio Setup (Load from .env)
// const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
// const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     const duplicate = donors.some(d => d.contact === contact);
//     if (duplicate) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save donor
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood & Send SMS to Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate input
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);
//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Find and notify matched donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         }).sort((a, b) => a.distance - b.distance).slice(0, 3); // Notify top 3 nearest donors

//     matchedDonors.forEach(donor => {
//         const message = `🩸 Urgent: Blood needed (${bloodGroup}) at ${hospital}. Contact: ${contact}`;
//         client.messages.create({
//             body: message,
//             from: TWILIO_PHONE,
//             to: `+91${donor.contact}`
//         }).then(() => console.log(`📲 SMS sent to ${donor.name}`))
//           .catch(err => console.error('❌ SMS Error:', err));
//     });

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });


// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const twilio = require('twilio');
// require('dotenv').config();

// // Initialize the app
// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure required directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Twilio Setup (Load from .env)
// if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
//     console.error('❌ Twilio credentials missing in .env file!');
//     process.exit(1);
// }
// const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
// const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     if (donors.some(d => d.contact === contact)) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save donor
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood & Send SMS to Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate input
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);
//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Find and notify matched donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         }).sort((a, b) => a.distance - b.distance).slice(0, 3); // Notify top 3 nearest donors

//     if (matchedDonors.length === 0) {
//         console.log("❗ No matching donors found.");
//         return res.status(404).send('❗ No matching donors available.');
//     }

//     matchedDonors.forEach(donor => {
//         const message = `🩸 Urgent: Blood needed (${bloodGroup}) at ${hospital}. Contact: ${contact}`;
//         client.messages.create({
//             body: message,
//             from: TWILIO_PHONE,
//             to: `+91${donor.contact}`
//         }).then(() => console.log(`📲 SMS sent to ${donor.name}`))
//           .catch(err => console.error('❌ SMS Error:', err));
//     });

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });




// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const twilio = require('twilio');
// require('dotenv').config();

// // Initialize the app
// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure required directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Twilio Setup (Load from .env)
// if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
//     console.error('❌ Twilio credentials missing in .env file!');
//     process.exit(1);
// }
// const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
// const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     if (isNaN(age) || age < 18 || age > 65) {
//         return res.status(400).send('❌ Age must be between 18 and 65!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).send('❌ Invalid contact number (10 digits required)!');
//     }

//     // Check for duplicate donors
//     const donors = loadData(donorsFilePath);
//     if (donors.some(d => d.contact === contact)) {
//         return res.status(409).send('⚠️ Donor already registered!');
//     }

//     // Save donor
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("🩸 New Donor Registered: ", newDonor);
//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Request Blood & Send SMS to Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate input
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields including location are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);
//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Find and notify matched donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         }).sort((a, b) => a.distance - b.distance).slice(0, 3); // Notify top 3 nearest donors

//     if (matchedDonors.length === 0) {
//         console.log("❗ No matching donors found.");
//         return res.status(404).send('❗ No matching donors available.');
//     }

//     // Send SMS to matched donors
//     matchedDonors.forEach(donor => {
//         const message = `🩸 Hello ${donor.name}, urgent blood needed (${bloodGroup}) at ${hospital}. Contact: ${contact}`;
//         client.messages.create({
//             body: message,
//             from: TWILIO_PHONE,
//             to: `+91${donor.contact}`
//         }).then(() => console.log(`📲 SMS sent to ${donor.name}`))
//           .catch(err => console.error('❌ SMS Error:', err));
//     });

//     // Confirmation to requester
//     client.messages.create({
//         body: `🩸 Blood request received! We're contacting donors for ${bloodGroup} near ${hospital}.`,
//         from: TWILIO_PHONE,
//         to: `+91${contact}`
//     }).catch(err => console.error('❌ SMS Error (Requester):', err));

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });




// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const twilio = require('twilio');
// require('dotenv').config();

// // Initialize the app
// const app = express();
// const PORT = process.env.PORT || 4000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure required directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Twilio Setup (Load from .env)
// if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
//     console.error('❌ Twilio credentials missing in .env file!');
//     process.exit(1);
// }
// const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
// const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// // OTP storage (Temporary)
// const otpStore = {};

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Generate OTP
// const generateOTP = () => Math.floor(100000 + Math.random() * 900000);

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Send OTP (For Blood Request)
// app.post('/send-otp', (req, res) => {
//     const { contact } = req.body;

//     // Validate contact number
//     if (!/^\d{10}$/.test(contact)) {
//         return res.status(400).json({ success: false, message: '❌ Invalid contact number!' });
//     }

//     const otp = generateOTP();
//     otpStore[contact] = { otp, expiresAt: Date.now() + 10 * 60 * 1000 }; // 10 minutes expiry

//     // Send OTP via SMS
//     client.messages.create({
//         body: `🩸 Your BloodConnect OTP is: ${otp}. Valid for 10 mins.`,
//         from: TWILIO_PHONE,
//         to: `+91${contact}`
//     }).then(() => {
//         console.log(`📲 OTP sent to ${contact}: ${otp}`);
//         res.json({ success: true, message: '✅ OTP sent successfully!' });
//     }).catch(err => {
//         console.error('❌ OTP Sending Error:', err);
//         res.status(500).json({ success: false, message: '❌ Failed to send OTP!' });
//     });
// });

// // Request Blood & Send SMS to Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude, otp } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude || !otp) {
//         return res.status(400).send('❌ All fields including OTP are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // OTP Verification
//     if (!otpStore[contact] || otpStore[contact].otp !== parseInt(otp) || Date.now() > otpStore[contact].expiresAt) {
//         return res.status(400).send('❌ Invalid or expired OTP!');
//     }
//     delete otpStore[contact]; // OTP used, delete it

//     // Save blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);
//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Find and notify matched donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         }).sort((a, b) => a.distance - b.distance).slice(0, 3); // Notify top 3 nearest donors

//     if (matchedDonors.length === 0) {
//         console.log("❗ No matching donors found.");
//         return res.status(404).send('❗ No matching donors available.');
//     }

//     // Send SMS to matched donors
//     matchedDonors.forEach(donor => {
//         const message = `🩸 Hello ${donor.name}, urgent blood needed (${bloodGroup}) at ${hospital}. Contact: ${contact}`;
//         client.messages.create({
//             body: message,
//             from: TWILIO_PHONE,
//             to: `+91${donor.contact}`
//         }).then(() => console.log(`📲 SMS sent to ${donor.name}`))
//           .catch(err => console.error('❌ SMS Error:', err));
//     });

//     // Confirmation to requester
//     client.messages.create({
//         body: `🩸 Blood request received! We're contacting donors for ${bloodGroup} near ${hospital}.`,
//         from: TWILIO_PHONE,
//         to: `+91${contact}`
//     }).catch(err => console.error('❌ SMS Error (Requester):', err));

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });
// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const twilio = require('twilio');
// require('dotenv').config();

// // Initialize app
// const app = express();
// const PORT = process.env.PORT || 4000;

// Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Ensure required directories exist
// const ensureDirectory = (dirPath) => {
//     if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//     }
// };
// ensureDirectory(path.join(__dirname, 'public'));

// // Data file paths
// const donorsFilePath = path.join(__dirname, 'public', 'donor.json');
// const requestsFilePath = path.join(__dirname, 'public', 'request.json');

// // Twilio Setup (Load from .env)
// if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
//     console.error('❌ Twilio credentials missing in .env file!');
//     process.exit(1);
// }
// const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
// const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// // Helper: Load Data
// const loadData = (filePath) => {
//     try {
//         if (!fs.existsSync(filePath)) return [];
//         const data = fs.readFileSync(filePath, 'utf8');
//         return JSON.parse(data);
//     } catch (err) {
//         console.error(`❌ Error reading ${filePath}:`, err);
//         return [];
//     }
// };

// // Helper: Save Data
// const saveData = (filePath, data) => {
//     try {
//         fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
//         console.log(`✅ Data saved to ${filePath}`);
//     } catch (err) {
//         console.error(`❌ Error saving data to ${filePath}:`, err);
//     }
// };

// // Helper: Calculate Distance (Haversine Formula)
// const calculateDistance = (lat1, lon1, lat2, lon2) => {
//     const toRadians = (deg) => deg * (Math.PI / 180);
//     const R = 6371; // Earth's radius in km
//     const dLat = toRadians(lat2 - lat1);
//     const dLon = toRadians(lon2 - lon1);
//     const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Donor Registration
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !city || !age || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save donor data
//     const newDonor = { name, bloodGroup: bloodGroup.toUpperCase(), contact, city, age, latitude, longitude };
//     const donors = loadData(donorsFilePath);
//     donors.push(newDonor);
//     saveData(donorsFilePath, donors);

//     console.log("✅ Donor Registered: ", newDonor);

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Submit Blood Request & Notify Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     // Validate fields
//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required!');
//     }

//     const validBloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
//     if (!validBloodGroups.includes(bloodGroup.toUpperCase())) {
//         return res.status(400).send('❌ Invalid blood group!');
//     }

//     // Save blood request
//     const newRequest = { name, bloodGroup: bloodGroup.toUpperCase(), contact, hospital, latitude, longitude };
//     const requests = loadData(requestsFilePath);
//     requests.push(newRequest);
//     saveData(requestsFilePath, requests);
//     console.log("✅ Blood Request Saved: ", newRequest);

//     // Find and notify matched donors
//     const donors = loadData(donorsFilePath);
//     const matchedDonors = donors.filter(d => d.bloodGroup === bloodGroup.toUpperCase())
//         .map(donor => {
//             const distance = calculateDistance(latitude, longitude, donor.latitude, donor.longitude);
//             return { ...donor, distance: distance.toFixed(2) };
//         }).sort((a, b) => a.distance - b.distance).slice(0, 3);

//     if (matchedDonors.length === 0) {
//         console.log("❗ No matching donors found.");
//         return res.status(404).send('❗ No matching donors available.');
//     }

//     matchedDonors.forEach(donor => {
//         const message = `🩸 Hello ${donor.name}, urgent blood needed (${bloodGroup}) at ${hospital}. Contact: ${contact}`;
//         client.messages.create({
//             body: message,
//             from: TWILIO_PHONE,
//             to: `+91${donor.contact}`
//         }).then(() => console.log(`📲 SMS sent to ${donor.name}`))
//           .catch(err => console.error('❌ SMS Error:', err));
//     });

//     client.messages.create({
//         body: `🩸 Blood request received! We're contacting donors for ${bloodGroup} near ${hospital}.`,
//         from: TWILIO_PHONE,
//         to: `+91${contact}`
//     }).catch(err => console.error('❌ SMS Error (Requester):', err));

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'));
// });

// // Start Server
// app.listen(PORT, () => {
//     console.log(`🚀 Server running at http://localhost:${PORT}`);
// });


// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const bodyParser = require('body-parser');
// const twilio = require('twilio');

// const app = express();
// const port = 3000;

// const donorsFile = path.join(__dirname, 'donors.json');
// const accountSid = 'YOUR_TWILIO_ACCOUNT_SID';
// const authToken = 'YOUR_TWILIO_AUTH_TOKEN';
// const twilioClient = twilio(accountSid, authToken);
// const twilioNumber = 'YOUR_TWILIO_PHONE_NUMBER';

// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static('public'));

// // Haversine Formula to calculate distance
// function getDistance(lat1, lon1, lat2, lon2) {
//     const toRad = (x) => (x * Math.PI) / 180;
//     const R = 6371; // Radius of Earth in km

//     const dLat = toRad(lat2 - lat1);
//     const dLon = toRad(lon2 - lon1);
//     const a =
//         Math.sin(dLat / 2) * Math.sin(dLat / 2) +
//         Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
//         Math.sin(dLon / 2) * Math.sin(dLon / 2);

//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// }

// // Load donor data
// const loadDonors = () => {
//     if (!fs.existsSync(donorsFile)) return [];
//     const data = fs.readFileSync(donorsFile);
//     return JSON.parse(data);
// };

// // Save donor data
// const saveDonors = (data) => {
//     fs.writeFileSync(donorsFile, JSON.stringify(data, null, 2));
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'index.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !city || !latitude || !longitude) {
//         return res.status(400).send('All fields are required');
//     }

//     const donors = loadDonors();
//     donors.push({ name, bloodGroup, contact, city, age, latitude, longitude });
//     saveDonors(donors);

//     res.send('✅ Donor registered successfully!');
// });

// // Find Nearest Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('All fields are required');
//     }

//     const donors = loadDonors();

//     // Filter compatible blood group donors
//     const compatibleDonors = donors.filter((donor) => donor.bloodGroup === bloodGroup);

//     if (compatibleDonors.length === 0) {
//         return res.send('❌ No matching donors found.');
//     }

//     // Calculate distance and sort by nearest
//     const nearestDonors = compatibleDonors.map((donor) => {
//         const distance = getDistance(latitude, longitude, parseFloat(donor.latitude), parseFloat(donor.longitude));
//         return { ...donor, distance };
//     }).sort((a, b) => a.distance - b.distance);

//     // Send SMS to the nearest donor
//     if (nearestDonors.length > 0) {
//         const nearest = nearestDonors[0];
//         const message = `🩸 Urgent Blood Request!
// Patient: ${name}
// Hospital: ${hospital}
// Contact: ${contact}

// You are the nearest ${bloodGroup} donor.`;

//         twilioClient.messages.create({
//             body: message,
//             from: twilioNumber,
//             to: nearest.contact,
//         }).then(() => {
//             res.send(`✅ Blood request sent to nearest donor: ${nearest.name}`);
//         }).catch((err) => {
//             console.error('Error sending SMS:', err);
//             res.status(500).send('❌ Failed to send message.');
//         });
//     } else {
//         res.send('❌ No donors available nearby.');
//     }
// });

// app.listen(port, () => {
//     console.log(`🚀 Server running on http://localhost:${port}`);
// });


// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const bodyParser = require('body-parser');
// const twilio = require('twilio');

// const app = express();
// const port = 3000;

// const donorsFile = path.join(__dirname, 'donors.json');
// const accountSid = 'YOUR_TWILIO_ACCOUNT_SID';
// const authToken = 'YOUR_TWILIO_AUTH_TOKEN';
// const twilioClient = twilio(accountSid, authToken);
// const twilioNumber = 'YOUR_TWILIO_PHONE_NUMBER';

// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static('public'));

// // Haversine Formula to calculate distance
// function getDistance(lat1, lon1, lat2, lon2) {
//     const toRad = (x) => (x * Math.PI) / 180;
//     const R = 6371; // Radius of Earth in km

//     const dLat = toRad(lat2 - lat1);
//     const dLon = toRad(lon2 - lon1);
//     const a =
//         Math.sin(dLat / 2) * Math.sin(dLat / 2) +
//         Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
//         Math.sin(dLon / 2) * Math.sin(dLon / 2);

//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// }

// // Load donor data
// const loadDonors = () => {
//     if (!fs.existsSync(donorsFile)) return [];
//     const data = fs.readFileSync(donorsFile);
//     return JSON.parse(data);
// };

// // Save donor data
// const saveDonors = (data) => {
//     fs.writeFileSync(donorsFile, JSON.stringify(data, null, 2));
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'index.html'));
// });

// // Serve Register Page
// app.get('/register', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public/register.html'));
// });

// // Serve Blood Request Page
// app.get('/request', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public/request.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !city || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required');
//     }

//     const donors = loadDonors();
//     donors.push({ name, bloodGroup, contact, city, age, latitude, longitude });
//     saveDonors(donors);

//     res.send('✅ Donor registered successfully!');
// });

// // Find Nearest Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required');
//     }

//     const donors = loadDonors();

//     // Filter compatible blood group donors
//     const compatibleDonors = donors.filter((donor) => donor.bloodGroup === bloodGroup);

//     if (compatibleDonors.length === 0) {
//         return res.send('❌ No matching donors found.');
//     }

//     // Calculate distance and sort by nearest
//     const nearestDonors = compatibleDonors.map((donor) => {
//         const distance = getDistance(latitude, longitude, parseFloat(donor.latitude), parseFloat(donor.longitude));
//         return { ...donor, distance };
//     }).sort((a, b) => a.distance - b.distance);

//     // Send SMS to the nearest donor
//     if (nearestDonors.length > 0) {
//         const nearest = nearestDonors[0];
//         const message = `🩸 Urgent Blood Request!\nPatient: ${name}\nHospital: ${hospital}\nContact: ${contact}\n\nYou are the nearest ${bloodGroup} donor.`;

//         twilioClient.messages.create({
//             body: message,
//             from: twilioNumber,
//             to: nearest.contact,
//         }).then(() => {
//             res.send(`✅ Blood request sent to nearest donor: ${nearest.name}`);
//         }).catch((err) => {
//             console.error('❌ Error sending SMS:', err);
//             res.status(500).send('❌ Failed to send message.');
//         });
//     } else {
//         res.send('❌ No donors available nearby.');
//     }
// });

// app.listen(port, () => {
//     console.log(`🚀 Server running on http://localhost:${port}`);
// });



// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const bodyParser = require('body-parser');
// const twilio = require('twilio');

// const app = express();
// const port = 3000;

// const donorsFile = path.join(__dirname, 'donors.json');
// const accountSid = 'YOUR_TWILIO_ACCOUNT_SID';
// const authToken = 'YOUR_TWILIO_AUTH_TOKEN';
// const twilioClient = twilio(accountSid, authToken);
// const twilioNumber = 'YOUR_TWILIO_PHONE_NUMBER';

// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'public')));

// // Haversine Formula to calculate distance
// function getDistance(lat1, lon1, lat2, lon2) {
//     const toRad = (x) => (x * Math.PI) / 180;
//     const R = 6371; // Radius of Earth in km

//     const dLat = toRad(lat2 - lat1);
//     const dLon = toRad(lon2 - lon1);
//     const a =
//         Math.sin(dLat / 2) * Math.sin(dLat / 2) +
//         Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
//         Math.sin(dLon / 2) * Math.sin(dLon / 2);

//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c; // Distance in km
// }

// // Load donor data
// const loadDonors = () => {
//     if (!fs.existsSync(donorsFile)) return [];
//     const data = fs.readFileSync(donorsFile);
//     return JSON.parse(data);
// };

// // Save donor data
// const saveDonors = (data) => {
//     fs.writeFileSync(donorsFile, JSON.stringify(data, null, 2));
// };

// // Home Page
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Serve Register Page
// app.get('/register', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'register.html'));
// });

// // Serve Blood Request Page
// app.get('/request', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'request.html'));
// });

// // Register Donor
// app.post('/register', (req, res) => {
//     const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !city || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required');
//     }

//     const donors = loadDonors();
//     donors.push({ name, bloodGroup, contact, city, age, latitude, longitude });
//     saveDonors(donors);

//     res.sendFile(path.join(__dirname, 'public', 'success_page.html'), (err) => {
//         if (err) {
//             console.error('❌ Error sending success page:', err);
//             res.status(500).send('❌ Error loading success page!');
//         }
//     });
// });

// // Find Nearest Donors
// app.post('/submit_request', (req, res) => {
//     const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

//     if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
//         return res.status(400).send('❌ All fields are required');
//     }

//     const donors = loadDonors();

//     // Filter compatible blood group donors
//     const compatibleDonors = donors.filter((donor) => donor.bloodGroup === bloodGroup);

//     if (compatibleDonors.length === 0) {
//         return res.send('❌ No matching donors found.');
//     }

//     // Calculate distance and sort by nearest
//     const nearestDonors = compatibleDonors.map((donor) => {
//         const distance = getDistance(latitude, longitude, parseFloat(donor.latitude), parseFloat(donor.longitude));
//         return { ...donor, distance };
//     }).sort((a, b) => a.distance - b.distance);

//     // Send SMS to the nearest donor
//     if (nearestDonors.length > 0) {
//         const nearest = nearestDonors[0];
//         const message = `🩸 Urgent Blood Request!\nPatient: ${name}\nHospital: ${hospital}\nContact: ${contact}\n\nYou are the nearest ${bloodGroup} donor.`;

//         twilioClient.messages.create({
//             body: message,
//             from: twilioNumber,
//             to: nearest.contact,
//         }).then(() => {
//             res.sendFile(path.join(__dirname, 'public', 'response.html'), (err) => {
//                 if (err) {
//                     console.error('❌ Error sending success page:', err);
//                     res.status(500).send('❌ Error loading success page!');
//                 }
//             });
//         }).catch((err) => {
//             console.error('❌ Error sending SMS:', err);
//             res.status(500).send('❌ Failed to send message.');
//         });
//     } else {
//         res.send('❌ No donors available nearby.');
//     }
// });

// app.listen(port, () => {
//     console.log(`🚀 Server running on http://localhost:${port}`);
// });



require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const twilio = require('twilio');

const app = express();
const port = 3000;

const donorsFile = path.join(__dirname, 'donors.json');
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioNumber = process.env.TWILIO_PHONE_NUMBER;
const twilioClient = twilio(accountSid, authToken);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Haversine Formula to calculate distance
function getDistance(lat1, lon1, lat2, lon2) {
    const toRad = (x) => (x * Math.PI) / 180;
    const R = 6371; // Radius of Earth in km

    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
}

// Load donor data
const loadDonors = () => {
    if (!fs.existsSync(donorsFile)) return [];
    const data = fs.readFileSync(donorsFile);
    return JSON.parse(data);
};

// Save donor data
const saveDonors = (data) => {
    fs.writeFileSync(donorsFile, JSON.stringify(data, null, 2));
};

// Home Page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve Register Page
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Serve Blood Request Page
app.get('/request', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'request.html'));
});

// Register Donor
app.post('/register', (req, res) => {
    const { name, bloodGroup, contact, city, age, latitude, longitude } = req.body;

    if (!name || !bloodGroup || !contact || !city || !latitude || !longitude) {
        return res.status(400).send('❌ All fields are required');
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);
    if (isNaN(lat) || isNaN(lon)) {
        return res.status(400).send('❌ Invalid location coordinates.');
    }

    const donors = loadDonors();
    donors.push({ name, bloodGroup, contact, city, age, latitude: lat, longitude: lon });
    saveDonors(donors);

    res.sendFile(path.join(__dirname, 'public', 'success_page.html'), (err) => {
        if (err) {
            console.error('❌ Error sending success page:', err);
            res.status(500).send('❌ Error loading success page!');
        }
    });
});

// Find Nearest Donors
app.post('/submit_request', (req, res) => {
    const { name, bloodGroup, contact, hospital, latitude, longitude } = req.body;

    if (!name || !bloodGroup || !contact || !hospital || !latitude || !longitude) {
        return res.status(400).send('❌ All fields are required');
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);
    if (isNaN(lat) || isNaN(lon)) {
        return res.status(400).send('❌ Invalid location coordinates.');
    }

    const donors = loadDonors();

    // Filter compatible blood group donors
    const compatibleDonors = donors.filter((donor) => donor.bloodGroup === bloodGroup);

    if (compatibleDonors.length === 0) {
        return res.send('❌ No matching donors found.');
    }

    // Calculate distance and sort by nearest
    const nearestDonors = compatibleDonors.map((donor) => {
        const distance = getDistance(lat, lon, parseFloat(donor.latitude), parseFloat(donor.longitude));
        return { ...donor, distance };
    }).sort((a, b) => a.distance - b.distance);

    // Send SMS to the nearest donor
    if (nearestDonors.length > 0) {
        const nearest = nearestDonors[0];
        const message = `🩸 Urgent Blood Request!\nPatient: ${name}\nHospital: ${hospital}\nContact: ${contact}\n\nYou are the nearest ${bloodGroup} donor.`;

        twilioClient.messages.create({
            body: message,
            from: twilioNumber,
            to: nearest.contact,
        }).then(() => {
            res.sendFile(path.join(__dirname, 'public', 'response.html'), (err) => {
                if (err) {
                    console.error('❌ Error sending success page:', err);
                    res.status(500).send('❌ Error loading success page!');
                }
            });
        }).catch((err) => {
            console.error('❌ Error sending SMS:', err);
            res.status(500).send('❌ Failed to send message.');
        });
    } else {
        res.send('❌ No donors available nearby.');
    }
});

app.listen(port, () => {
    console.log(`🚀 Server running on http://localhost:${port}`);
});